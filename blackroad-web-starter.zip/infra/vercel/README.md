# Vercel Setup

For each app in `apps/*` create a Vercel project:
- Project Root: the corresponding app directory, e.g., `apps/blackroad-network`
- Framework: Next.js
- Build Command: `next build`
- Output directory: `.next`
- Development Command: `next dev`

Domains to bind (one or more per project):
- core: blackroad.network, blackroad.systems (optional)
- research: blackroadai.com, blackroadqi.com, blackroadquantum.com
- campus: lucidia.earth, lucidia.studio
- persona: aliceqi.com, lucidiaqi.com

If prompted, add verification TXT records in Cloudflare.
