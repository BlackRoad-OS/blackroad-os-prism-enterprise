# BlackRoad Web Starter

Monorepo with multiple Next.js apps (App Router) and a shared UI package.

## Apps
- blackroad.network
- blackroad.systems
- blackroad.me
- blackroadai.com
- blackroadqi.com
- blackroadquantum.com
- lucidia.earth
- lucidia.studio
- aliceqi.com
- lucidiaqi.com

## Quickstart

```bash
# Choose a package manager (pnpm recommended)
corepack enable
corepack prepare pnpm@latest --activate

pnpm install
pnpm dev   # starts all apps concurrently on different ports
```

Each app will run on an incrementing port starting at 3000.

## Deploy (Vercel, suggested)

- Create one project per app and bind the appropriate domain in Vercel.
- Set the root directory for each project to `apps/<folder>`.
- Domains:
  - blackroad.network
  - blackroad.systems
  - blackroad.me
  - blackroadai.com
  - blackroadqi.com
  - blackroadquantum.com
  - lucidia.earth
  - lucidia.studio
  - aliceqi.com
  - lucidiaqi.com

## Notes
- Tailwind and a tiny shared design system live in `packages/ui`.
- You can import shared components using `@br/ui`.
- Security headers and a simple CSP are added via `next.config.js`.
