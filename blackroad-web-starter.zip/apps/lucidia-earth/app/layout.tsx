import './styles/globals.css'
import type { Metadata } from 'next'
import { Header } from '@br/ui'

export const metadata: Metadata = {
  title: 'lucidia.earth',
  description: 'Creator campus: city-in-the-garden.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header title="lucidia.earth" subtitle="Creator campus: city-in-the-garden." />
        <main className="container py-10">{children}</main>
      </body>
    </html>
  )
}
