import './styles/globals.css'
import type { Metadata } from 'next'
import { Header } from '@br/ui'

export const metadata: Metadata = {
  title: 'blackroadquantum.com',
  description: 'Research lab, demos, and papers.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header title="blackroadquantum.com" subtitle="Research lab, demos, and papers." />
        <main className="container py-10">{children}</main>
      </body>
    </html>
  )
}
