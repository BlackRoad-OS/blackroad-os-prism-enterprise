import './styles/globals.css'
import type { Metadata } from 'next'
import { Header } from '@br/ui'

export const metadata: Metadata = {
  title: 'blackroadai.com',
  description: 'APIs, SDKs, pricing, and keys for BlackRoad AI.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header title="blackroadai.com" subtitle="APIs, SDKs, pricing, and keys for BlackRoad AI." />
        <main className="container py-10">{children}</main>
      </body>
    </html>
  )
}
