import './styles/globals.css'
import type { Metadata } from 'next'
import { Header } from '@br/ui'

export const metadata: Metadata = {
  title: 'blackroad.systems',
  description: 'Infrastructure, OS, and hardware orchestration.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header title="blackroad.systems" subtitle="Infrastructure, OS, and hardware orchestration." />
        <main className="container py-10">{children}</main>
      </body>
    </html>
  )
}
