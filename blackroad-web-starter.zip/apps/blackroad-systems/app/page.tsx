import { Button } from '@br/ui'

export default function Page() {
  return (
    <section className="hero">
      <h1 className="hero-title">blackroad.systems</h1>
      <p className="hero-sub mt-3">Infrastructure, OS, and hardware orchestration.</p>
      <div className="mt-6 flex gap-3">
        <Button onClick={() => window.location.href='/docs'}>Read the docs</Button>
        <Button className="bg-white/90" onClick={() => window.location.href='/contact'}>Get in touch</Button>
      </div>
    </section>
  )
}
