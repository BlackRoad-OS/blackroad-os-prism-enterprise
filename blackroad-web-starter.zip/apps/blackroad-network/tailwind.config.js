/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*{js,ts,jsx,tsx,mdx}",
    "../../packages/ui/src/**/*{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        road: {
          black: "#0a0a0a",
          teal: "#14b8a6",
          sky: "#0ea5e9",
          cyan: "#22d3ee"
        }
      },
      borderRadius: {
        'xl': '1rem',
        '2xl': '1.25rem'
      }
    }
  },
  plugins: []
};
