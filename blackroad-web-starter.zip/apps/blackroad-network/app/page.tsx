import { Button } from '@br/ui'

export default function Page() {
  return (
    <section className="hero">
      <h1 className="hero-title">blackroad.network</h1>
      <p className="hero-sub mt-3">The agent network and public home of BlackRoad.</p>
      <div className="mt-6 flex gap-3">
        <Button onClick={() => window.location.href='/docs'}>Read the docs</Button>
        <Button className="bg-white/90" onClick={() => window.location.href='/contact'}>Get in touch</Button>
      </div>
    </section>
  )
}
