import './styles/globals.css'
import type { Metadata } from 'next'
import { Header } from '@br/ui'

export const metadata: Metadata = {
  title: 'lucidia.studio',
  description: 'Design + education studio, courses and tools.'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Header title="lucidia.studio" subtitle="Design + education studio, courses and tools." />
        <main className="container py-10">{children}</main>
      </body>
    </html>
  )
}
