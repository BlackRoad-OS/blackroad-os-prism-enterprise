import * as React from 'react';

export function Header({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <header className="w-full border-b border-neutral-800/50 bg-neutral-950/60 backdrop-blur supports-[backdrop-filter]:bg-neutral-950/40">
      <div className="mx-auto max-w-6xl px-6 py-5 flex items-center justify-between">
        <div className="flex flex-col">
          <h1 className="text-xl md:text-2xl font-semibold tracking-tight text-white">{title}</h1>
          {subtitle ? <p className="text-sm text-neutral-300/80">{subtitle}</p> : null}
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm text-neutral-300">
          <a className="hover:text-white transition" href="/docs">Docs</a>
          <a className="hover:text-white transition" href="/status">Status</a>
          <a className="hover:text-white transition" href="/privacy">Privacy</a>
        </nav>
      </div>
    </header>
  );
}
