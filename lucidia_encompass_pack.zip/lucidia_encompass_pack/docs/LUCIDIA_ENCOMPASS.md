# Lucidia‑Encompass

This directory contains a reference implementation of the Lucidia‑Encompass
meta‑agent described in our conversation. The aggregator contacts multiple
personas, collects structured JSON responses and then computes a winner
and consensus score.

## Running the aggregator

To run the command‑line demo you need Python 3.11 and, optionally,
access to an OpenAI‑compatible API (for example a local vLLM server).

1. Install Python dependencies (if any) and ensure the `openai` package
   is available. Set `SILAS_BASE_URL` to your local model endpoint or
   leave it unset to default to `http://localhost:8000/v1`. You may also
   set `SILAS_API_KEY` and `SILAS_MODEL` as needed.
2. Export `SAFE_MODE=1` to enforce read‑only behaviour.
3. Run:

   ```bash
   python scripts/encompass_demo.py --prompt "Who are we?"
   ```

The script prints a JSON object with the chosen winner, a consensus
coherence score, and the raw packets from each persona.

## Viewing persona packets

The `ui/lucidia_viewer` directory contains a simple HTML viewer for
persona packets. To use it:

1. Save the JSON output from the demo as `ui/lucidia_viewer/packets.json`.
2. Run:

   ```bash
   npm --prefix ui/lucidia_viewer run preview
   ```

3. Open <http://localhost:5173> (or whatever port you set via `PORT`)
   in your browser. The page will display each persona, its stance and
   a few words of its content coloured according to the balanced‑ternary
   value.