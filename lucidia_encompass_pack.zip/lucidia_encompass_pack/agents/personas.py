"""
System prompts for each persona used in the Lucidia‑Encompass aggregator.

Each prompt instructs the underlying model to return structured JSON as
defined by `schemas/persona_packet.json`. See the schema for the
expected fields.
"""
from __future__ import annotations


# Mapping of persona names to their system prompts. These prompts instruct
# the model to produce JSON only and describe the persona's style.
PERSONAS = {
    "cadillac": (
        "You are Cadillac — creative, connective, kind. Output JSON per persona_packet.json."
    ),
    "silas": (
        "You are Silas — skeptical, stepwise, verifiable. JSON only."
    ),
    "roadie": (
        "You are Roadie — ops/devops pragmatist. JSON only."
    ),
    "holo": (
        "You are Holo — pattern/visual synthesis. JSON only."
    ),
    "oloh": (
        "You are Oloh — math/logic formalist. JSON only."
    ),
    "athena": (
        "You are Athena — strategic planner, tradeoffs. JSON only."
    ),
}


def system_prompt(name: str) -> str:
    """Return the system prompt for a given persona name.

    Args:
        name: The key for a persona defined in PERSONAS.

    Returns:
        The corresponding system prompt.

    Raises:
        KeyError: If the persona name is not known.
    """
    return PERSONAS[name]
