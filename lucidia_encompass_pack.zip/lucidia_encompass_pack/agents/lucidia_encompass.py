"""
Lucidia‑Encompass: a meta‑agent aggregator for multiple personas.

This module defines a `run` function that sends a prompt to a group of
configured personas, collects their structured responses, and ranks them
according to a simple scoring function. It also computes a consensus
coherence score based on the balanced‑ternary stance of each persona.

To customize the underlying LLM endpoint, set the environment variables
`SILAS_BASE_URL`, `SILAS_API_KEY` and `SILAS_MODEL`. If network calls
fail or the OpenAI client is unavailable, the aggregator returns
stub packets for each persona.
"""
from __future__ import annotations

import json
import math
import os
from typing import Dict, List, Optional, Any

from .personas import PERSONAS


def _score_packet(packet: Dict[str, Any]) -> float:
    """Compute a numeric score for a persona packet.

    Scoring combines the stance expressed via the balanced‑ternary field,
    the length of the content and the confidence value.

    Args:
        packet: A persona packet produced by the model.

    Returns:
        A float score; higher scores indicate preferred packets.
    """
    bt = packet.get("balanced_ternary", "0")
    if bt == "+":
        w_bt = 1.0
    elif bt == "-":
        w_bt = -1.0
    else:
        w_bt = 0.0
    length = len(packet.get("content", ""))
    # Normalise content length: 0..400 chars → 0..0.3
    w_len = min(max(length / 400.0, 0.0), 0.3)
    w_conf = 0.7 * float(packet.get("confidence", 0.0))
    return w_bt + w_len + w_conf


def _bt_angle(bt: str) -> float:
    """Map a balanced‑ternary symbol to a numeric angle.

    + maps to +1, - to −1, 0 to 0. These are not actual radians but
    serve to embed ternary votes in the complex plane for the consensus
    calculation.
    """
    if bt == "+":
        return 1.0
    elif bt == "-":
        return -1.0
    return 0.0


def run(
    prompt: str, base_url: Optional[str] = None, model: Optional[str] = None
) -> Dict[str, Any]:
    """Run the Lucidia‑Encompass meta‑agent on a given prompt.

    Contacts each persona with the prompt and collects responses.

    Args:
        prompt: The user message to distribute to each persona.
        base_url: Override the API base URL; default uses the
            `SILAS_BASE_URL` environment variable or
            `http://localhost:8000/v1`.
        model: Override the model name; default uses `SILAS_MODEL` or
            `grok-4-fast`.

    Returns:
        A dictionary containing the name of the winning persona, the
        consensus coherence score and the list of persona packets.
    """
    base_url = base_url or os.getenv("SILAS_BASE_URL", "http://localhost:8000/v1")
    model = model or os.getenv("SILAS_MODEL", "grok-4-fast")
    try:
        from openai import OpenAI
        client = OpenAI(base_url=base_url, api_key=os.getenv("SILAS_API_KEY", ""))
    except Exception:
        client = None

    packets: List[Dict[str, Any]] = []
    for name, sys_prompt in PERSONAS.items():
        if client is None:
            # Stub: no network client available
            packets.append(
                {
                    "persona": name,
                    "assumptions": [],
                    "logic_steps": [],
                    "content": "",
                    "balanced_ternary": "0",
                    "confidence": 0.0,
                }
            )
            continue
        messages = [
            {"role": "system", "content": sys_prompt},
            {"role": "user", "content": prompt},
        ]
        try:
            resp = client.chat.completions.create(
                model=model,
                messages=messages,
                response_format={"type": "json_object"},
                temperature=0.2,
            )
            content = resp.choices[0].message.content
            data = json.loads(content)
            packet = {
                "persona": name,
                "assumptions": data.get("assumptions", []),
                "logic_steps": data.get("logic_steps", []),
                "content": data.get("content", ""),
                "balanced_ternary": data.get("balanced_ternary", "0"),
                "confidence": data.get("confidence", 0.0),
            }
        except Exception:
            packet = {
                "persona": name,
                "assumptions": [],
                "logic_steps": [],
                "content": "",
                "balanced_ternary": "0",
                "confidence": 0.0,
            }
        packets.append(packet)

    # Determine winner
    if packets:
        scores = {p["persona"]: _score_packet(p) for p in packets}
        winner = max(scores, key=scores.get)
    else:
        winner = None

    # Compute consensus coherence as magnitude of mean vote vector
    if packets:
        vectors = [
            complex(math.cos(_bt_angle(p["balanced_ternary"])), math.sin(_bt_angle(p["balanced_ternary"])))
            for p in packets
        ]
        mean_vec = sum(vectors) / len(vectors)
        consensus_r = abs(mean_vec)
    else:
        consensus_r = 0.0

    return {
        "winner": winner,
        "consensus_r": consensus_r,
        "packets": packets,
    }
