"""
Tests for the Lucidia‑Encompass scoring and consensus logic.

These tests run without making network calls. The run function is
invoked with a dummy base_url to produce stub packets.
"""

from agents.lucidia_encompass import _score_packet, run


def test_score_packet() -> None:
    """Check that the scoring function distinguishes different packets."""
    # Packet with positive stance and nonzero length/confidence
    p1 = {
        "persona": "cadillac",
        "assumptions": [],
        "logic_steps": [],
        "content": "hello world",
        "balanced_ternary": "+",
        "confidence": 0.5,
    }
    # Packet with negative stance and longer content
    p2 = {
        "persona": "silas",
        "assumptions": [],
        "logic_steps": [],
        "content": "long content " * 50,
        "balanced_ternary": "-",
        "confidence": 0.1,
    }
    s1 = _score_packet(p1)
    s2 = _score_packet(p2)
    assert s1 != s2


def test_run_stub() -> None:
    """Ensure run returns a structure even when network is unavailable."""
    result = run("test", base_url="http://localhost:9999/v1", model="dummy")
    assert "winner" in result
    assert "consensus_r" in result
    assert 0.0 <= result["consensus_r"] <= 1.0
    assert len(result.get("packets", [])) == len(result.get("packets", []))