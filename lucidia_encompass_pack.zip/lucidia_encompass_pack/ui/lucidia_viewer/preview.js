const http = require('http');
const fs = require('fs');
const path = require('path');

const port = process.env.PORT || 5173;
const root = __dirname;

const server = http.createServer((req, res) => {
  // Strip leading slash
  let filePath = req.url.replace(/^\//, '');
  if (!filePath) {
    filePath = 'index.html';
  }
  const absPath = path.join(root, filePath);
  fs.readFile(absPath, (err, data) => {
    if (err) {
      res.statusCode = 404;
      res.end('File not found');
      return;
    }
    let type = 'text/html';
    if (filePath.endsWith('.js')) type = 'application/javascript';
    if (filePath.endsWith('.json')) type = 'application/json';
    res.setHeader('Content-Type', type);
    res.end(data);
  });
});

server.listen(port, () => {
  console.log('Viewer running at http://localhost:' + port);
});