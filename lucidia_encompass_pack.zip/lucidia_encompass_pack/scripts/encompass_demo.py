#!/usr/bin/env python3
"""
Command‑line demo for the Lucidia‑Encompass meta‑agent.

This script sends a prompt to all configured personas and prints the
aggregated response in JSON format. It is safe by default and does
not attempt to modify any external state.
"""
from __future__ import annotations

import argparse
import json
from agents.lucidia_encompass import run


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run the Lucidia‑Encompass meta‑agent on a prompt."
    )
    parser.add_argument(
        "--prompt",
        default="Who are we?",
        help="User prompt to send to each persona.",
    )
    args = parser.parse_args()
    result = run(args.prompt)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()