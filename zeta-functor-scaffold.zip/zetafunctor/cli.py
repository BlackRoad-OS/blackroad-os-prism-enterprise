import argparse, sys, json
import numpy as np
from zetafunctor.hashing import rolling_sha256, hash_to_c
from zetafunctor.mandelbrot import escape_time
from zetafunctor.graphing import bigram_adjacency, edge_list_to_adjacency
from zetafunctor.zeta import zeta_scan, radius_bound

def cmd_mandelbrot(args):
    with open(args.input, 'r', encoding='utf-8') as f:
        text = f.read()
    hashes = rolling_sha256(text, chunk=args.chunk)
    escapes = [escape_time(hash_to_c(h), max_iter=args.max_iter) for h in hashes]
    print(json.dumps({
        "count": len(escapes),
        "mean_escape": float(np.mean(escapes)) if escapes else None,
        "histogram_bins": args.bins
    }))
    if args.plot:
        import matplotlib.pyplot as plt
        plt.hist(escapes, bins=args.bins)
        plt.title("Escape Time Histogram")
        plt.savefig(args.plot, dpi=144)

def cmd_zeta_text(args):
    with open(args.input, 'r', encoding='utf-8') as f:
        text = f.read()
    A = bigram_adjacency(text)
    r = radius_bound(A)
    zs, vals = zeta_scan(A, z_min=0.0, z_max=min(args.zmax, 0.95), num=args.samples)
    print(json.dumps({
        "radius_bound": r,
        "samples": args.samples
    }))
    if args.plot:
        import matplotlib.pyplot as plt
        plt.plot(zs, vals)
        plt.title("|ζ_A(z)| along real axis")
        plt.savefig(args.plot, dpi=144)

def main(argv=None):
    p = argparse.ArgumentParser(prog="zetafunctor")
    sub = p.add_subparsers(dest="cmd")

    q = sub.add_parser("mandelbrot")
    q.add_argument("--input", required=True, help="Text file")
    q.add_argument("--chunk", type=int, default=512)
    q.add_argument("--max-iter", type=int, default=200)
    q.add_argument("--bins", type=int, default=30)
    q.add_argument("--plot", default="histogram_mandelbrot_escape.png")
    q.set_defaults(func=cmd_mandelbrot)

    r = sub.add_parser("zeta-text")
    r.add_argument("--input", required=True, help="Text file")
    r.add_argument("--zmax", type=float, default=0.9)
    r.add_argument("--samples", type=int, default=200)
    r.add_argument("--plot", default="zeta_mag_plot.png")
    r.set_defaults(func=cmd_zeta_text)

    args = p.parse_args(argv)
    if not hasattr(args, "func"):
        p.print_help()
        return 2
    return args.func(args)

if __name__ == "__main__":
    sys.exit(main())
