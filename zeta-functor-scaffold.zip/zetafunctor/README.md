# zeta-functor scaffold

This is a minimal scaffold that ties together:
- **Pipeline A**: Text → rolling SHA-256 → c-plane seeds → Mandelbrot escape-time stats
- **Pipeline B**: Text / edge-list → weighted graph → dynamical zeta \(\zeta_A(z)=1/\det(I - zA)\)
- **Extras**: prime-indexed sampling, adjacency weighting (e.g., Bible cross-reference counts)

> No internet access: bring your own text/cross-ref CSV or paste it into the demo.

## Install (local)
```bash
# (inside this folder)
python -m venv .venv && source .venv/bin/activate
pip install numpy scipy matplotlib
```

## Layout
- `zetafunctor/hashing.py` — rolling SHA-256 and hash→c mapping
- `zetafunctor/mandelbrot.py` — escape-time computation
- `zetafunctor/graphing.py` — build adjacency matrices from text bigrams or edge lists; normalize/weight
- `zetafunctor/zeta.py` — evaluate 1/det(I - zA) along rays/discs; basic spectral helpers
- `zetafunctor/primes.py` — simple sieve and prime-index sampling
- `cli.py` — small demo CLI

## Example
```bash
python demo.py
# Produces:
# - histogram_mandelbrot_escape.png
# - zeta_mag_plot.png
```

## Notes on Bible cross-ref weighting
If you have a cross-reference table like `book:chapter:verse -> book:chapter:verse`, build an edge list
with counts. A good default weight is `w = log(1 + count)` to damp hubs. Row-normalize the adjacency 
to get a stochastic matrix A, then analyze `1/det(I - zA)` along `z ∈ [0, r)` where `r < 1/ρ(A)`.
