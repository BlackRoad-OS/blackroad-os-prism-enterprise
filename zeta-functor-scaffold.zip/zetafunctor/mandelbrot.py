from typing import List

def escape_time(c: complex, max_iter: int = 200) -> int:
    """Escape time for the quadratic map z -> z^2 + c."""
    z = 0j
    for n in range(max_iter):
        z = z*z + c
        if (z.real*z.real + z.imag*z.imag) > 4.0:
            return n
    return max_iter
