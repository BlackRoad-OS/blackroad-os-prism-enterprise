from typing import List

def sieve(n: int) -> List[int]:
    """Return all primes <= n."""
    if n < 2:
        return []
    b = [True] * (n+1)
    b[0] = b[1] = False
    p = 2
    while p*p <= n:
        if b[p]:
            for k in range(p*p, n+1, p):
                b[k] = False
        p += 1
    return [i for i in range(n+1) if b[i]]

def prime_index_subsequence(seq):
    """Return subsequence of seq at prime indices (1-based)."""
    # Convert to 1-based logic
    import math
    # Gather primes up to len(seq)
    ps = sieve(len(seq))
    out = [seq[i-1] for i in ps if 1 <= i <= len(seq)]
    return out
