# Minimal demo that runs both pipelines on a tiny text snippet.
# Produces two PNGs alongside the script.
from zetafunctor.hashing import rolling_sha256, hash_to_c
from zetafunctor.mandelbrot import escape_time
from zetafunctor.graphing import bigram_adjacency
from zetafunctor.zeta import zeta_scan
import numpy as np
import matplotlib.pyplot as plt

TEXT = """In the beginning, code and cosmos echoed each other.
Cycles gave way to meaning, and meaning to cycles."""

# Pipeline A
hashes = rolling_sha256(TEXT, chunk=32)
escapes = [escape_time(hash_to_c(h), max_iter=150) for h in hashes]
plt.hist(escapes, bins=20)
plt.title("Escape Time Histogram (demo)")
plt.savefig("histogram_mandelbrot_escape.png", dpi=144)
plt.clf()

# Pipeline B
A = bigram_adjacency(TEXT)
zs, vals = zeta_scan(A, z_min=0.0, z_max=0.9, num=150)
plt.plot(zs, vals)
plt.title("|ζ_A(z)| along real axis (demo)")
plt.savefig("zeta_mag_plot.png", dpi=144)
