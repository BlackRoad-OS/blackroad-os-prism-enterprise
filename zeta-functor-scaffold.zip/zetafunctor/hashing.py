import hashlib
from typing import List, Tuple

def rolling_sha256(text: str, chunk: int = 1024) -> List[bytes]:
    """Compute rolling SHA-256 over prefixes of `text`.
    Returns list of 32-byte digests.
    """
    hs = []
    for i in range(0, len(text), chunk):
        prefix = text[: i + chunk]
        hs.append(hashlib.sha256(prefix.encode('utf-8')).digest())
    return hs

def hash_to_c(h: bytes, scale: float = 2.0) -> complex:
    """Map first 16 bytes of hash to c=x+iy in [-scale, scale]^2."""
    x = int.from_bytes(h[:8], 'big') / (1 << 64) * 2 * scale - scale
    y = int.from_bytes(h[8:16], 'big') / (1 << 64) * 2 * scale - scale
    return complex(x, y)
