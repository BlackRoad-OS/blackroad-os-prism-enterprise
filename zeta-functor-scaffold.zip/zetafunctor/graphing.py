import numpy as np
from typing import Dict, List, Tuple, Optional
import math

def bigram_adjacency(text: str, alphabet: str = None) -> np.ndarray:
    """Build a simple bigram count matrix over a given alphabet.
    If alphabet is None, use lowercase a-z.
    """
    if alphabet is None:
        alphabet = 'abcdefghijklmnopqrstuvwxyz'
    idx = {ch:i for i, ch in enumerate(alphabet)}
    A = np.zeros((len(alphabet), len(alphabet)), dtype=float)
    t = [c for c in text.lower() if c in idx]
    for a, b in zip(t, t[1:]):
        A[idx[a], idx[b]] += 1.0
    return A

def edge_list_to_adjacency(edges: List[Tuple[int,int,int]], size: int, log_damp: bool = True, row_norm: bool = True) -> np.ndarray:
    """Edges as (u, v, count) over node ids in [0, size).
    If log_damp, weight = log(1 + count); else weight = count.
    If row_norm, normalize rows to sum to 1 (stochastic).
    """
    A = np.zeros((size, size), dtype=float)
    for u, v, c in edges:
        w = math.log1p(c) if log_damp else float(c)
        A[u, v] += w
    if row_norm:
        rs = A.sum(axis=1, keepdims=True)
        A = np.divide(A, np.where(rs==0, 1.0, rs), where=True)
    return A
