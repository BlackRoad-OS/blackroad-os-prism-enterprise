import numpy as np
from scipy.linalg import det, eigvals
from typing import Tuple

def zeta_det(A: np.ndarray, z: complex) -> complex:
    """Return 1 / det(I - z A)."""
    I = np.eye(A.shape[0])
    return 1.0 / det(I - z * A)

def radius_bound(A: np.ndarray) -> float:
    """Simple bound for radius of convergence: 1 / spectral_radius(A)."""
    vals = eigvals(A)
    rho = max(abs(vals))
    return 1.0 / float(rho) if rho > 0 else float('inf')

def zeta_scan(A: np.ndarray, z_min: float = 0.0, z_max: float = 0.95, num: int = 200) -> tuple:
    """Evaluate |zeta| along the real segment [z_min, z_max)."""
    zs = np.linspace(z_min, z_max, num, endpoint=False)
    vals = np.array([abs(zeta_det(A, z)) for z in zs])
    return zs, vals
