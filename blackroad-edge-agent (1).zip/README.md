# BlackRoad Edge Agent (Jetson/Pi)
Capture → vitals (C,Tr,S) → trust T → Emit gate → POST /ingest.
See .env.example for config. Dockerfiles for CPU & Jetson.
