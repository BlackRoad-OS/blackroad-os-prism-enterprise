import requests
def post_vitals(base_url,agent_id,C,Tr,S,tags=None):
    payload={"id":agent_id,"C":C,"Tr":Tr,"S":S,"tags":tags or []}
    url=f"{base_url.rstrip('/')}/ingest"
    r=requests.post(url,json=payload,timeout=5)
    return r.status_code,r.text
