import sys,time,json,signal
from . import config
from .capture import open_stream,read_frame
from .infer import vitals_from_frame
from .metrics import trust,can_emit
from .sender import post_vitals
_running=True
def _sig(_s,_f):
    global _running; _running=False
def main():
    signal.signal(signal.SIGINT,_sig)
    cap=open_stream(config.CAMERA_INDEX,config.GST_PIPELINE)
    if cap is None:
        print(json.dumps({"event":"camera_open_failed"})); return 1
    print(json.dumps({"event":"edge_agent_start","id":config.AGENT_ID}))
    while _running:
        frame=read_frame(cap)
        if frame is None: time.sleep(0.5); continue
        C,Tr,S,feats=vitals_from_frame(frame)
        T=trust(C,Tr,S,config.TRUST_A_C,config.TRUST_A_TR,config.TRUST_A_E)
        allowed=can_emit(("forbid" not in config.TAGS),T,config.TRUST_THRESHOLD)
        print(json.dumps({"event":"vitals","id":config.AGENT_ID,"C":round(C,3),"Tr":round(Tr,3),"S":round(S,3),"T":round(T,3),"allowed":allowed,"tags":config.TAGS,"feats":{k:round(float(v),3) for k,v in feats.items()}}))
        try:
            status,_=post_vitals(config.GATEWAY_URL,config.AGENT_ID,C,Tr,S,tags=config.TAGS)
            print(json.dumps({"event":"ingest_resp","status":status}))
        except Exception as e:
            print(json.dumps({"event":"ingest_error","error":str(e)}))
        time.sleep(config.INTERVAL_SEC)
    try: cap.release()
    except: pass
    print(json.dumps({"event":"edge_agent_stop"})); return 0
if __name__=="__main__":
    sys.exit(main())
