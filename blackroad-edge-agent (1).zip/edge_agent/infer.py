import numpy as np, cv2
def entropy_gray(img):
    hist=cv2.calcHist([img],[0],None,[256],[0,256]).ravel()
    p=hist/(img.size+1e-9); p=p[p>0]
    return float(-(p*np.log2(p)).sum()/8.0)
def vitals_from_frame(frame):
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    brightness=float(gray.mean()/255.0)
    sharp=float(cv2.Laplacian(gray,cv2.CV_64F).var()); sharp_n=min(1.0, sharp/500.0)
    S=float(max(0.0,min(1.0,entropy_gray(gray))))
    C=float(np.clip(0.5*brightness+0.5*sharp_n,0.0,1.0))
    Tr=float(np.clip(0.7+0.2*(sharp_n>0.2),0.0,1.0))
    return C,Tr,S,{"brightness":brightness,"sharpness":sharp,"entropy":S}
