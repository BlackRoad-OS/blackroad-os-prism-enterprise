import os
def _f(env, default):
    try: return float(os.getenv(env, default))
    except Exception: return float(default)
GATEWAY_URL=os.getenv("GATEWAY_URL","http://127.0.0.1:8080")
AGENT_ID=os.getenv("AGENT_ID","edge-agent")
CAMERA_INDEX=int(os.getenv("CAMERA_INDEX","0"))
GST_PIPELINE=os.getenv("GST_PIPELINE","")
LOVE_USER=_f("LOVE_USER",0.45); LOVE_TEAM=_f("LOVE_TEAM",0.25); LOVE_WORLD=_f("LOVE_WORLD",0.30)
TRUST_A_C=_f("TRUST_A_C",0.8); TRUST_A_TR=_f("TRUST_A_TR",0.5); TRUST_A_E=_f("TRUST_A_E",0.7)
TRUST_THRESHOLD=_f("TRUST_THRESHOLD",0.62)
TAGS=[t for t in os.getenv("TAGS","").split(",") if t.strip()]
INTERVAL_SEC=float(os.getenv("INTERVAL_SEC","2.0"))
