import math
def trust(C,Tr,S,aC=0.8,aTr=0.5,aE=0.7):
    x=aC*C+aTr*Tr-aE*S
    return 1/(1+math.exp(-x))
def can_emit(in_covenant,T,tau=0.62):
    return bool(in_covenant and T>=tau)
