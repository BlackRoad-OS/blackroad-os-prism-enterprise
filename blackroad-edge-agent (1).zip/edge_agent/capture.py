import cv2
def open_stream(camera_index=0, gst_pipeline=''):
    cap=cv2.VideoCapture(gst_pipeline, cv2.CAP_GSTREAMER) if gst_pipeline else cv2.VideoCapture(camera_index)
    return cap if cap.isOpened() else None
def read_frame(cap):
    ok,frame=cap.read()
    return frame if ok else None
